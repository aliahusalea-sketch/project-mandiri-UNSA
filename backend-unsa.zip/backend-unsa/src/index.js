const express = require('express');
const cors = require('cors');
require('dotenv').config();
const mahasiswaRoutes = require('./routes/mahasiswaRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Endpoint Health Check untuk Frontend (PengaturanApi.tsx)
app.get('/api/health', async (req, res) => {
  try {
    res.status(200).json({ 
      status: 'OK', 
      database: 'mahasiswa_unsa' 
    });
  } catch (err) {
    res.status(500).json({ error: 'Database tidak merespons' });
  }
});

// Routes Utama Mahasiswa
app.use('/api/mahasiswa', mahasiswaRoutes);

app.get('/', (req, res) => {
  res.send('API Data Mahasiswa UNSA Berjalan');
});

// Menjalankan server
app.listen(PORT, () => {
  console.log(`Server backend berjalan di http://localhost:${PORT}`);
});