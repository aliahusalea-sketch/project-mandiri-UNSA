const pool = require('../config/db');

// Ambil semua data mahasiswa
const getAllMahasiswa = async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM mahasiswa ORDER BY id ASC');
    res.status(200).json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Tambah mahasiswa baru
const createMahasiswa = async (req, res) => {
  const { 
    nim, 
    nama_mahasiswa, 
    jenis_kelamin, 
    tempat_lahir, 
    prodi, 
    kelas, 
    semester, 
    alamat, 
    nama_ibu, 
    no_hp, 
    keterangan 
  } = req.body;

  try {
    const result = await pool.query(
      `INSERT INTO mahasiswa (nim, nama_mahasiswa, jenis_kelamin, tempat_lahir, prodi, kelas, semester, alamat, nama_ibu, no_hp, keterangan) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING *`,
      [nim, nama_mahasiswa, jenis_kelamin, tempat_lahir, prodi, kelas, semester || 1, alamat, nama_ibu, no_hp, keterangan || 'Aktif']
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Update data mahasiswa
const updateMahasiswa = async (req, res) => {
  const { id } = req.params;
  const { 
    nim, 
    nama_mahasiswa, 
    jenis_kelamin, 
    tempat_lahir, 
    prodi, 
    kelas, 
    semester, 
    alamat, 
    nama_ibu, 
    no_hp, 
    keterangan 
  } = req.body;

  try {
    const result = await pool.query(
      `UPDATE mahasiswa 
       SET nim = $1, nama_mahasiswa = $2, jenis_kelamin = $3, tempat_lahir = $4, prodi = $5, kelas = $6, semester = $7, alamat = $8, nama_ibu = $9, no_hp = $10, keterangan = $11 
       WHERE id = $12 RETURNING *`,
      [nim, nama_mahasiswa, jenis_kelamin, tempat_lahir, prodi, kelas, semester, alamat, nama_ibu, no_hp, keterangan, id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Mahasiswa tidak ditemukan' });
    }
    res.status(200).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Hapus data mahasiswa
const deleteMahasiswa = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query('DELETE FROM mahasiswa WHERE id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Mahasiswa tidak ditemukan' });
    }
    res.status(200).json({ message: 'Data berhasil dihapus' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  getAllMahasiswa,
  createMahasiswa,
  updateMahasiswa,
  deleteMahasiswa,
};