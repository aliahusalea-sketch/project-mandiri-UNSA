const pool = require('../config/db');

// GET: Ambil semua data users beserta data mahasiswanya (JOIN)
exports.getAllUsers = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT users.*, mahasiswa.nama_mahasiswa, mahasiswa.nim 
      FROM users 
      JOIN mahasiswa ON users.id_mhs = mahasiswa.id
    `);
    res.json(result.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};

// POST: Tambah user baru
exports.createUser = async (req, res) => {
  try {
    const { uuid, id_mhs, email, password, created_by } = req.body;
    const newUser = await pool.query(
      `INSERT INTO users (uuid, id_mhs, email, password, created_by, updated_by) 
       VALUES ($1, $2, $3, $4, $5, $5) RETURNING *`,
      [uuid, id_mhs, email, password, created_by || 'Admin']
    );
    res.json(newUser.rows[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};

// PATCH: Edit data user berdasarkan UUID
exports.updateUser = async (req, res) => {
  try {
    const { uuid } = req.params;
    const { email, password, updated_by } = req.body;
    
    const updateUser = await pool.query(
      `UPDATE users SET email = COALESCE($1, email), password = COALESCE($2, password), 
       updated_at = CURRENT_TIMESTAMP, updated_by = COALESCE($3, updated_by) 
       WHERE uuid = $4 RETURNING *`,
      [email, password, updated_by, uuid]
    );

    res.json({ message: 'Data user berhasil diperbarui', data: updateUser.rows[0] });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};

// DELETE: Hapus user berdasarkan UUID (Hard delete atau sesuaikan kebutuhan)
exports.deleteUser = async (req, res) => {
  try {
    const { uuid } = req.params;
    await pool.query('DELETE FROM users WHERE uuid = $1', [uuid]);
    res.json({ message: 'User berhasil dihapus.' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};