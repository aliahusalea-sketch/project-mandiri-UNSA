const express = require('express');
const router = express.Router();
const {
  getAllMahasiswa,
  createMahasiswa,
  updateMahasiswa,
  deleteMahasiswa,
} = require('../controllers/mahasiswaController');

router.get('/', getAllMahasiswa);
router.post('/', createMahasiswa);
router.put('/:id', updateMahasiswa);
router.delete('/:id', deleteMahasiswa);

module.exports = router;