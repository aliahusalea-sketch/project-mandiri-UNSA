import React, { useEffect, useState } from 'react';
import { Mahasiswa } from '../types/mahasiswa';
import { getMahasiswa, createMahasiswa, updateMahasiswa, deleteMahasiswa } from '../services/api';
import { StatCard } from '../components/StatCard';
import { ModalMahasiswa } from '../components/ModalMahasiswa';

export const DashboardMahasiswa: React.FC = () => {
  const [data, setData] = useState<Mahasiswa[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Mahasiswa | null>(null);

  const fetchData = async () => {
    try {
      setLoading(true);
      const res = await getMahasiswa();
      setData(res.data);
    } catch (error) {
      console.error('Gagal mengambil data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSave = async (formData: Mahasiswa) => {
    try {
      if (editingItem && editingItem.id) {
        await updateMahasiswa(editingItem.id, formData);
      } else {
        await createMahasiswa(formData);
      }
      setIsModalOpen(false);
      setEditingItem(null);
      fetchData();
    } catch (error) {
      alert('Gagal menyimpan data. Pastikan NIM tidak duplikat.');
    }
  };

  const handleDelete = async (id?: number) => {
    if (!id || !confirm('Yakin ingin menghapus data mahasiswa ini?')) return;
    try {
      await deleteMahasiswa(id);
      fetchData();
    } catch (error) {
      alert('Gagal menghapus data.');
    }
  };

  const totalKelas = new Set(data.map((m) => m.kelas)).size;
  const totalProdi = new Set(data.map((m) => m.prodi)).size;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Manajemen Data Mahasiswa</h1>
          <p className="text-sm text-slate-500">Universitas SA - Terhubung dengan Database DBeaver</p>
        </div>
        <button
          onClick={() => {
            setEditingItem(null);
            setIsModalOpen(true);
          }}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition cursor-pointer"
        >
          + Tambah Mahasiswa
        </button>
      </div>

      {/* Statistik */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="TOTAL MAHASISWA" value={data.length} subtitle="Mahasiswa aktif terdaftar" />
        <StatCard title="MAHASISWA AKTIF" value={data.length} subtitle="Status aktif" />
        <StatCard title="TOTAL KELAS / ROMBEL" value={totalKelas} subtitle="Kelas aktif" />
      </div>

      {/* Tabel Data */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                <th className="py-3 px-4 font-semibold">NIM</th>
                <th className="py-3 px-4 font-semibold">NAMA LENGKAP</th>
                <th className="py-3 px-4 font-semibold">L/P</th>
                <th className="py-3 px-4 font-semibold">TEMPAT LAHIR</th>
                <th className="py-3 px-4 font-semibold">KELAS / ROMBEL</th>
                <th className="py-3 px-4 font-semibold">ALAMAT</th>
                <th className="py-3 px-4 font-semibold">NAMA IBU</th>
                <th className="py-3 px-4 font-semibold">NO. HP / WALI</th>
                <th className="py-3 px-4 font-semibold">KETERANGAN</th>
                <th className="py-3 px-4 font-semibold text-right">AKSI</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {loading ? (
                <tr>
                  <td colSpan={10} className="py-8 text-center text-slate-500">
                    Memuat data...
                  </td>
                </tr>
              ) : data.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-8 text-center text-slate-500">
                    Belum ada data mahasiswa. Klik "+ Tambah Mahasiswa" atau masukkan data via DBeaver.
                  </td>
                </tr>
              ) : (
                data.map((mhs) => (
                  <tr key={mhs.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-medium text-blue-600">{mhs.nim}</td>
                    {/* Menggunakan nama_mahasiswa sesuai kolom database */}
                    <td className="py-3 px-4 font-medium text-slate-800">{mhs.nama_mahasiswa}</td>
                    <td className="py-3 px-4 text-slate-600">{mhs.jenis_kelamin || '-'}</td>
                    {/* Menggunakan tempat_lahir sesuai kolom database */}
                    <td className="py-3 px-4 text-slate-600">{mhs.tempat_lahir || '-'}</td>
                    <td className="py-3 px-4">
                      <span className="px-2.5 py-1 bg-blue-50 text-blue-700 rounded-md font-medium text-xs">
                        {mhs.kelas}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600">{mhs.alamat || '-'}</td>
                    <td className="py-3 px-4 text-slate-600">{mhs.nama_ibu || '-'}</td>
                    <td className="py-3 px-4 text-slate-600">{mhs.no_hp || '-'}</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded text-xs font-semibold">
                        {mhs.keterangan || 'Aktif'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right space-x-2">
                      <button
                        onClick={() => {
                          setEditingItem(mhs);
                          setIsModalOpen(true);
                        }}
                        className="text-blue-600 hover:underline font-medium cursor-pointer"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(mhs.id)}
                        className="text-red-600 hover:underline font-medium cursor-pointer"
                      >
                        Hapus
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <ModalMahasiswa
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleSave}
        initialData={editingItem}
      />
    </div>
  );
};