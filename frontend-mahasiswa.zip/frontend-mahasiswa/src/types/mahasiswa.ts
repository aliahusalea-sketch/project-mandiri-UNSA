export interface Mahasiswa {
  id?: number;
  nim: string;
  nama_mahasiswa: string;
  jenis_kelamin?: string;
  tempat_lahir?: string;
  prodi?: string;
  kelas?: string;
  semester?: number;
  alamat?: string;
  nama_ibu?: string;
  no_hp?: string;
  keterangan?: string;
}