import axios from 'axios';

// Arahkan base URL ke root backend /api
const api = axios.create({
  baseURL: 'http://localhost:3000/api',
});

export default api;

// Panggil menggunakan path relatif dari baseURL
export const getMahasiswa = () => api.get('/mahasiswa');
export const createMahasiswa = (data) => api.post('/mahasiswa', data);
export const updateMahasiswa = (id, data) => api.put(`/mahasiswa/${id}`, data);
export const deleteMahasiswa = (id) => api.delete(`/mahasiswa/${id}`);