import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import { DashboardMahasiswa } from './pages/DashboardMahasiswa';
import RombelKelas from './pages/RombelKelas';
import PengaturanApi from './pages/PengaturanApi';
import { getMahasiswa } from './services/api';
import type { Mahasiswa } from './types/mahasiswa';

export default function App() {
  const [activeMenu, setActiveMenu] = useState<string>('dashboard');
  const [dataMahasiswa, setDataMahasiswa] = useState<Mahasiswa[]>([]);

  // Ambil data global mahasiswa agar bisa dibagikan ke RombelKelas / Dashboard
  useEffect(() => {
    getMahasiswa()
      .then((res) => setDataMahasiswa(res.data))
      .catch((err) => console.error('Gagal memuat data:', err));
  }, []);

  return (
    <div className="flex h-screen bg-slate-100 overflow-hidden">
      {/* Sidebar Navigasi Kiri */}
      <Sidebar activeMenu={activeMenu} setActiveMenu={setActiveMenu} />

      {/* Konten Utama di Kanan */}
      <main className="flex-1 overflow-y-auto">
        {activeMenu === 'dashboard' && <DashboardMahasiswa />}
        {activeMenu === 'mahasiswa' && <DashboardMahasiswa />}
        {activeMenu === 'rombel' && <RombelKelas dataMahasiswa={dataMahasiswa} />}
        {activeMenu === 'pengaturan' && <PengaturanApi />}
      </main>
    </div>
  );
}